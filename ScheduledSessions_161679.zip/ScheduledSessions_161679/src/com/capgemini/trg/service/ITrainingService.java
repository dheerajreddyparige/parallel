package com.capgemini.trg.service;

import java.util.ArrayList;

import com.capgemini.trg.model.ScheduledSessions;



public interface ITrainingService {
	public ArrayList<ScheduledSessions> getAllSessions();
}
