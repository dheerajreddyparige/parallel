package com.capgemini.trg.service;

import java.util.ArrayList;

import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.trg.dao.ITrainingDAO;
import com.capgemini.trg.model.ScheduledSessions;
@Service
@Transactional
public class TrainingServiceImpl implements ITrainingService {
	
  @Autowired
ITrainingDAO sessionDao;
	@Override
	public ArrayList<ScheduledSessions> getAllSessions() {
		
		return sessionDao.getAllSessions();
	}

}
