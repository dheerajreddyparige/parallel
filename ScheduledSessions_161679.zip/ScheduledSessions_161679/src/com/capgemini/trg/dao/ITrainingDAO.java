package com.capgemini.trg.dao;

import java.util.ArrayList;

import com.capgemini.trg.model.ScheduledSessions;

public interface ITrainingDAO {
public ArrayList<ScheduledSessions> getAllSessions();
}
