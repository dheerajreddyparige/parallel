package com.capgemini.trg.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.trg.model.ScheduledSessions;

@Repository
public class TrainingDAOImpl implements ITrainingDAO {
	
@PersistenceContext
EntityManager manager;

	@Override
	public ArrayList<ScheduledSessions> getAllSessions() {
		ArrayList<ScheduledSessions> list=new ArrayList<>();
		String jpql = "Select scheduled from scheduledsessions scheduled";
		TypedQuery<ScheduledSessions> query = manager.createQuery(jpql, ScheduledSessions.class);
		list = (ArrayList<ScheduledSessions>) query.getResultList();
		return list;
	}

}
