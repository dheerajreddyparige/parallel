package com.capgemini.trg.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.capgemini.trg.model.ScheduledSessions;
import com.capgemini.trg.service.ITrainingService;



@Controller
public class TrainingController {
	@Autowired
	ITrainingService service;
	
	@RequestMapping("/home")
	public String displayPage(Model model) {
		String view = "ScheduledSessions";
		ArrayList<ScheduledSessions> list = service.getAllSessions();
		model.addAttribute("sessionslist", list);
		return view;
	}
	}

